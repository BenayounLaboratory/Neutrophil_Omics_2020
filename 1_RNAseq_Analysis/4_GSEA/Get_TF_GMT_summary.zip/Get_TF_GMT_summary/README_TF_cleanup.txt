README


######### TF-LOF
# get FOXOs from Genome Research gmt
#     - save into FOXO-LOF_GEO.gmt

# Concatenate GEO TF-LOF for processing
cat GEO_TF_Perturb_DWN_Harmonizome_2020-03-25.gmt GEO_TF_Perturb_UP_Harmonizome_2020-03-25.gmt FOXO-LOF_GEO.gmt > GEO_TF_Perturb_Harmonizome_2020-03-25_UP_DOWN_FOXO.gmt

# make summary GMT
./clean_GEO_gmt.pl GEO_TF_Perturb_Harmonizome_2020-03-25_UP_DOWN_FOXO.gmt

# summarize ENCODE, ChEA, JASPAR and GEO for GSEA
./summarize_TF_gmt.pl 2020-05-20_GEO_Harmonizome_Target_summary.gmt JASPAR_TF_targets_Harmonizome_2020-03-31.gmt ENCODE_TFs_Harmonizome_2020-03-25.gmt CHEA_Harmonizome_2020-03-25.gmt