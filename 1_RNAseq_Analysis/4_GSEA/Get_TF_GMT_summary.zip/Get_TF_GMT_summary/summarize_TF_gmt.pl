#! /usr/bin/perl

use warnings;
use strict;
use List::MoreUtils qw(uniq);

# a script to extract a gene list from big files
# modified to put 0s when no data found

unless (scalar @ARGV > 1) {
	die "\n summarize_TF_gmt.pl <TF GMT file 1> ... <TF GMT file n>.\n";

}

# create final summary database
my %database_summary = ();

# loop over database files
foreach my $database (@ARGV) {
	
	# open current database
	unless (open(DATA, $database)) {
		die "cannot open $database file. \n";
	}
	
	while (my $line = <DATA>) {
		
		$line =~ s/\n//g; # remove newline so that gene name is recognized
		$line =~ s/\r//g; # remove newline so that gene name is recognized
	
		my @tmp = get_line_data ($line);
		
		my $TF = shift @tmp; # removes 1st element, is the TF name
		my $setinfo = shift @tmp; # removes 2nd element
		
		push (@{$database_summary{$TF}}, @tmp);
	}
	
	close DATA;
}


#print keys %database;
open(GMT, '>', "2020-05-20_TF_targets_ChEA_ENCODE_GEO_JASPAR_summary.gmt");

foreach my $tf (sort keys %database_summary) {

	print GMT $tf."\tTF_target_Summary\t".join("\t", uniq @{$database_summary{$tf}} )."\n";

}

close GMT;

exit;

###########################################################
# SUBROUTINES
###########################################################

###########################################################
# a subroutine that separates fields from a data line and
# returns them in an array

sub get_line_data {

    my $line = $_[0];
    
    chomp $line;  

    my @linedata = split(/\t/, $line);
        
    return @linedata;
}